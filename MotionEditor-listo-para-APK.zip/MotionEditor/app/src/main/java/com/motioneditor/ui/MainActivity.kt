package com.motioneditor.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.motioneditor.R
import com.motioneditor.engine.CompositionRenderer
import com.motioneditor.model.Composition
import com.motioneditor.model.ImageLayer
import com.motioneditor.model.Layer
import com.motioneditor.model.TextLayer
import com.motioneditor.effects.GlowEffect
import com.motioneditor.effects.MotionBlurEffect

/**
 * Very basic demo Activity.
 * Shows a composition with a text layer that moves and has motion blur + glow.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var composition: Composition
    private lateinit var renderer: CompositionRenderer
    private lateinit var preview: ImageView
    private lateinit var timeLabel: TextView
    private lateinit var seekBar: SeekBar

    private var currentTimeMs: Long = 0L
    @Volatile private var playing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preview = findViewById(R.id.preview)
        timeLabel = findViewById(R.id.timeLabel)
        seekBar = findViewById(R.id.seekBar)
        val playButton = findViewById<Button>(R.id.playButton)

        setupComposition()
        renderer = CompositionRenderer()

        seekBar.max = composition.durationMs.toInt()
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    currentTimeMs = progress.toLong()
                    renderFrame()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        playButton.setOnClickListener {
            // Simple play loop (not production ready)
            if (playing) return@setOnClickListener
            playing = true
            Thread {
                var t = 0L
                while (playing && t <= composition.durationMs) {
                    currentTimeMs = t
                    runOnUiThread {
                        seekBar.progress = t.toInt()
                        renderFrame()
                    }
                    Thread.sleep(33) // ~30fps
                    t += 33
                }
                playing = false
            }.start()
        }

        renderFrame()
    }

    override fun onDestroy() {
        playing = false
        super.onDestroy()
    }

    private fun setupComposition() {
        composition = Composition(
            name = "Demo Project",
            width = 1080,
            height = 1920,
            frameRate = 30,
            durationMs = 5000L
        )

        // Text layer with animation
        val text = TextLayer(
            text = "Motion Editor",
            textSize = 96f,
            textColor = Color.WHITE,
            name = "Title"
        )
        text.positionX = 200f
        text.positionY = 800f

        // Keyframes: move from left to right
        text.addKeyframe(Layer.Property.POSITION_X, 0L, 100f)
        text.addKeyframe(Layer.Property.POSITION_X, 2500L, 700f, com.motioneditor.model.Easing.EASE_IN_OUT)
        text.addKeyframe(Layer.Property.POSITION_X, 5000L, 200f)

        // Scale pulse
        text.addKeyframe(Layer.Property.SCALE_X, 0L, 1f)
        text.addKeyframe(Layer.Property.SCALE_X, 1250L, 1.4f, com.motioneditor.model.Easing.EASE_OUT)
        text.addKeyframe(Layer.Property.SCALE_X, 2500L, 1f)
        text.addKeyframe(Layer.Property.SCALE_Y, 0L, 1f)
        text.addKeyframe(Layer.Property.SCALE_Y, 1250L, 1.4f, com.motioneditor.model.Easing.EASE_OUT)
        text.addKeyframe(Layer.Property.SCALE_Y, 2500L, 1f)

        // Effects
        text.effects.add(GlowEffect(radius = 18f, color = 0xFF00E5FF.toInt()))
        text.effects.add(MotionBlurEffect(intensity = 1.2f))

        composition.addLayer(text)
    }

    private fun renderFrame() {
        val frame = renderer.render(composition, currentTimeMs)
        preview.setImageBitmap(frame)
        timeLabel.text = "Time: ${currentTimeMs} ms"
    }
}