package com.motioneditor.model

import android.graphics.Color
import android.graphics.Typeface

/**
 * Simple text layer.
 */
class TextLayer(
    var text: String = "Text",
    var textSize: Float = 64f,
    var textColor: Int = Color.WHITE,
    var typeface: Typeface = Typeface.DEFAULT_BOLD,
    name: String = "Text Layer"
) : Layer(name = name) {

    // Approximate size (real measurement needs Paint)
    override fun getWidth(): Float = text.length * textSize * 0.6f
    override fun getHeight(): Float = textSize * 1.3f
}