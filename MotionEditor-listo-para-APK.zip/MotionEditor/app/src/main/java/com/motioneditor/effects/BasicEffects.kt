package com.motioneditor.effects

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.motioneditor.model.Effect

/**
 * Simple Gaussian-like blur approximation using Paint.
 * Real production blur needs multi-pass or GPU shaders.
 */
class BlurEffect(
    var radius: Float = 8f
) : Effect {
    override val name: String = "Blur"

    override fun apply(paint: Paint, timeMs: Long) {
        // Android Paint doesn't have real Gaussian blur on Canvas easily.
        // This is a placeholder. In a real app you would use:
        // - RenderScript (deprecated)
        // - OpenGL shader
        // - or a multi-pass box blur
        paint.maskFilter = android.graphics.BlurMaskFilter(radius, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }
}

/**
 * Opacity / Fade effect (can also be driven by layer opacity keyframes)
 */
class OpacityEffect(
    var opacity: Float = 1f
) : Effect {
    override val name: String = "Opacity"

    override fun apply(paint: Paint, timeMs: Long) {
        paint.alpha = (opacity.coerceIn(0f, 1f) * 255).toInt()
    }
}

/**
 * Simple color adjustment (brightness / contrast / saturation)
 */
class ColorAdjustEffect(
    var brightness: Float = 0f,   // -1 .. 1
    var contrast: Float = 1f,     // 0 .. 2
    var saturation: Float = 1f    // 0 .. 2
) : Effect {
    override val name: String = "Color Adjust"

    override fun apply(paint: Paint, timeMs: Long) {
        val matrix = ColorMatrix()

        // Saturation
        matrix.setSaturation(saturation)

        // Contrast + Brightness
        val scale = contrast
        val translate = (-.5f * scale + .5f + brightness) * 255f
        val contrastMatrix = ColorMatrix(floatArrayOf(
            scale, 0f, 0f, 0f, translate,
            0f, scale, 0f, 0f, translate,
            0f, 0f, scale, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        ))
        matrix.postConcat(contrastMatrix)

        paint.colorFilter = ColorMatrixColorFilter(matrix)
    }
}

/**
 * Very basic motion blur approximation.
 * Real motion blur needs velocity vectors and multiple samples.
 * This version just increases blur based on a "speed" parameter.
 */
class MotionBlurEffect(
    var intensity: Float = 1f,          // overall strength
    var samples: Int = 5                // how many samples (higher = better but slower)
) : Effect {
    override val name: String = "Motion Blur"

    // In a real implementation this would receive velocity from the animation engine
    var currentSpeed: Float = 0f

    override fun apply(paint: Paint, timeMs: Long) {
        val radius = (currentSpeed * intensity).coerceIn(0f, 40f)
        if (radius > 0.5f) {
            paint.maskFilter = android.graphics.BlurMaskFilter(radius, android.graphics.BlurMaskFilter.Blur.NORMAL)
        }
    }
}

/**
 * Glow effect (simple outer glow approximation)
 */
class GlowEffect(
    var radius: Float = 12f,
    var color: Int = 0xFFFFFFFF.toInt()
) : Effect {
    override val name: String = "Glow"

    override fun apply(paint: Paint, timeMs: Long) {
        paint.setShadowLayer(radius, 0f, 0f, color)
    }
}