package com.motioneditor.model

import android.graphics.Bitmap

/**
 * Layer that holds a static image or video frame.
 */
class ImageLayer(
    var bitmap: Bitmap? = null,
    name: String = "Image Layer"
) : Layer(name = name) {

    override fun getWidth(): Float = bitmap?.width?.toFloat() ?: 100f
    override fun getHeight(): Float = bitmap?.height?.toFloat() ?: 100f
}