package com.motioneditor.model

import android.graphics.Matrix
import android.graphics.Paint
import java.util.UUID

/**
 * Base class for all layers in the composition.
 * Supports position, scale, rotation, opacity and keyframed properties.
 */
abstract class Layer(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "Layer"
) {
    // Transform properties (can be keyframed)
    var positionX: Float = 0f
    var positionY: Float = 0f
    var scaleX: Float = 1f
    var scaleY: Float = 1f
    var rotation: Float = 0f          // degrees
    var opacity: Float = 1f           // 0..1
    var anchorX: Float = 0.5f         // 0..1 relative
    var anchorY: Float = 0.5f

    var isVisible: Boolean = true
    var isLocked: Boolean = false

    // Parenting (simple parent-child)
    var parentId: String? = null

    // Effects applied to this layer
    val effects = mutableListOf<Effect>()

    // Keyframes for animated properties
    val keyframes = mutableMapOf<Property, MutableList<Keyframe>>()

    enum class Property {
        POSITION_X, POSITION_Y,
        SCALE_X, SCALE_Y,
        ROTATION,
        OPACITY
    }

    fun addKeyframe(property: Property, timeMs: Long, value: Float, easing: Easing = Easing.LINEAR) {
        val list = keyframes.getOrPut(property) { mutableListOf() }
        // Remove existing keyframe at same time
        list.removeAll { it.timeMs == timeMs }
        list.add(Keyframe(timeMs, value, easing))
        list.sortBy { it.timeMs }
    }

    fun getValueAtTime(property: Property, timeMs: Long): Float {
        val list = keyframes[property] ?: return getDefaultValue(property)
        if (list.isEmpty()) return getDefaultValue(property)
        if (timeMs <= list.first().timeMs) return list.first().value
        if (timeMs >= list.last().timeMs) return list.last().value

        // Find surrounding keyframes
        var prev = list[0]
        var next = list[1]
        for (i in 0 until list.size - 1) {
            if (timeMs >= list[i].timeMs && timeMs <= list[i + 1].timeMs) {
                prev = list[i]
                next = list[i + 1]
                break
            }
        }

        val t = (timeMs - prev.timeMs).toFloat() / (next.timeMs - prev.timeMs).toFloat()
        val easedT = next.easing.apply(t)
        return prev.value + (next.value - prev.value) * easedT
    }

    private fun getDefaultValue(property: Property): Float = when (property) {
        Property.POSITION_X -> positionX
        Property.POSITION_Y -> positionY
        Property.SCALE_X -> scaleX
        Property.SCALE_Y -> scaleY
        Property.ROTATION -> rotation
        Property.OPACITY -> opacity
    }

    /** Apply current transform to a Matrix */
    fun getTransformMatrix(timeMs: Long, width: Float, height: Float): Matrix {
        val matrix = Matrix()

        val px = getValueAtTime(Property.POSITION_X, timeMs)
        val py = getValueAtTime(Property.POSITION_Y, timeMs)
        val sx = getValueAtTime(Property.SCALE_X, timeMs)
        val sy = getValueAtTime(Property.SCALE_Y, timeMs)
        val rot = getValueAtTime(Property.ROTATION, timeMs)

        val ax = width * anchorX
        val ay = height * anchorY

        matrix.postTranslate(-ax, -ay)
        matrix.postScale(sx, sy)
        matrix.postRotate(rot)
        matrix.postTranslate(px + ax, py + ay)

        return matrix
    }

    abstract fun getWidth(): Float
    abstract fun getHeight(): Float
}

data class Keyframe(
    val timeMs: Long,
    val value: Float,
    val easing: Easing = Easing.LINEAR
)

enum class Easing {
    LINEAR,
    EASE_IN,
    EASE_OUT,
    EASE_IN_OUT,
    BOUNCE;

    fun apply(t: Float): Float {
        val clamped = t.coerceIn(0f, 1f)
        return when (this) {
            LINEAR -> clamped
            EASE_IN -> clamped * clamped
            EASE_OUT -> 1f - (1f - clamped) * (1f - clamped)
            EASE_IN_OUT -> {
                if (clamped < 0.5f) 2f * clamped * clamped
                else 1f - (-2f * clamped + 2f).let { it * it } / 2f
            }
            BOUNCE -> {
                // Simple bounce approximation
                val n1 = 7.5625f
                val d1 = 2.75f
                when {
                    clamped < 1f / d1 -> n1 * clamped * clamped
                    clamped < 2f / d1 -> n1 * (clamped - 1.5f / d1).let { it * it } + 0.75f
                    clamped < 2.5f / d1 -> n1 * (clamped - 2.25f / d1).let { it * it } + 0.9375f
                    else -> n1 * (clamped - 2.625f / d1).let { it * it } + 0.984375f
                }
            }
        }
    }
}

/**
 * Marker interface / base for effects
 */
interface Effect {
    val name: String
    fun apply(paint: Paint, timeMs: Long)
}