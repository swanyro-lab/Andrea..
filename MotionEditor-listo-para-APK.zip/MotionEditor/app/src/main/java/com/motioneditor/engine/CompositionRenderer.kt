package com.motioneditor.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import com.motioneditor.model.Composition
import com.motioneditor.model.ImageLayer
import com.motioneditor.model.Layer
import com.motioneditor.model.TextLayer
import com.motioneditor.effects.MotionBlurEffect

/**
 * Renders a Composition at a specific time into a Bitmap.
 * This is a software (Canvas) renderer for simplicity.
 * A production app would use OpenGL ES / Vulkan for performance.
 */
class CompositionRenderer {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    fun render(composition: Composition, timeMs: Long): Bitmap {
        val bitmap = Bitmap.createBitmap(
            composition.width,
            composition.height,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)

        // Clear background
        canvas.drawColor(Color.BLACK, PorterDuff.Mode.CLEAR)
        canvas.drawColor(Color.BLACK)

        // Draw layers from bottom to top
        composition.getVisibleLayers().forEach { layer ->
            drawLayer(canvas, layer, timeMs)
        }

        return bitmap
    }

    private fun drawLayer(canvas: Canvas, layer: Layer, timeMs: Long) {
        if (!layer.isVisible) return

        val opacity = layer.getValueAtTime(Layer.Property.OPACITY, timeMs)
        if (opacity <= 0.01f) return

        canvas.save()

        val matrix = layer.getTransformMatrix(timeMs, layer.getWidth(), layer.getHeight())
        canvas.concat(matrix)

        paint.reset()
        paint.isAntiAlias = true
        paint.alpha = (opacity * 255).toInt()

        // Apply effects
        layer.effects.forEach { effect ->
            // Special case for motion blur: we would need velocity here
            if (effect is MotionBlurEffect) {
                // Approximate speed from recent keyframes (very basic)
                effect.currentSpeed = estimateSpeed(layer, timeMs)
            }
            effect.apply(paint, timeMs)
        }

        when (layer) {
            is ImageLayer -> {
                layer.bitmap?.let { bmp ->
                    canvas.drawBitmap(bmp, 0f, 0f, paint)
                }
            }
            is TextLayer -> {
                paint.color = layer.textColor
                paint.textSize = layer.textSize
                paint.typeface = layer.typeface
                canvas.drawText(layer.text, 0f, layer.textSize, paint)
            }
            // Add more layer types later (Shape, Video, etc.)
        }

        canvas.restore()
    }

    /**
     * Very rough speed estimation for motion blur.
     * Real implementation would track previous positions.
     */
    private fun estimateSpeed(layer: Layer, timeMs: Long): Float {
        val dt = 33L // ~1 frame at 30fps
        val x1 = layer.getValueAtTime(Layer.Property.POSITION_X, timeMs)
        val y1 = layer.getValueAtTime(Layer.Property.POSITION_Y, timeMs)
        val x0 = layer.getValueAtTime(Layer.Property.POSITION_X, timeMs - dt)
        val y0 = layer.getValueAtTime(Layer.Property.POSITION_Y, timeMs - dt)

        val dx = x1 - x0
        val dy = y1 - y0
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }
}