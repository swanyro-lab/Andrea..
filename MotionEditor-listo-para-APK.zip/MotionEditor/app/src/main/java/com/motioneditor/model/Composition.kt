package com.motioneditor.model

/**
 * Represents a full project / composition.
 * Contains all layers, duration, resolution and frame rate.
 */
class Composition(
    var name: String = "Untitled Project",
    var width: Int = 1080,
    var height: Int = 1920,
    var frameRate: Int = 30,
    var durationMs: Long = 10_000L
) {
    val layers = mutableListOf<Layer>()

    fun addLayer(layer: Layer) {
        layers.add(layer)
    }

    fun removeLayer(layerId: String) {
        layers.removeAll { it.id == layerId }
    }

    fun getLayer(id: String): Layer? = layers.find { it.id == id }

    fun getVisibleLayers(): List<Layer> = layers.filter { it.isVisible }

    /** Total number of frames */
    fun totalFrames(): Int = ((durationMs / 1000.0) * frameRate).toInt()

    fun timeToFrame(timeMs: Long): Int = ((timeMs / 1000.0) * frameRate).toInt()

    fun frameToTime(frame: Int): Long = ((frame.toDouble() / frameRate) * 1000).toLong()
}