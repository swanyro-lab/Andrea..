# Motion Editor – Código Fuente Base

App original de edición de video / motion graphics para Android (Kotlin).

**Esto NO es una copia de Alight Motion.**  
Es una base limpia y bien estructurada desde la que se puede construir una app propia.

## Qué incluye este código

### Modelo (`model/`)
- `Layer.kt` → Clase base de capas con:
  - Transformaciones (posición, escala, rotación, opacidad)
  - Sistema de **keyframes** con varios tipos de easing
  - Parenting simple
  - Lista de efectos
- `Composition.kt` → Proyecto completo (resolución, duración, fps, capas)
- `ImageLayer.kt` y `TextLayer.kt` → Tipos de capas básicos

### Efectos (`effects/`)
- Blur
- Opacity
- Color Adjust (brillo / contraste / saturación)
- **Motion Blur** (aproximación por velocidad)
- Glow

### Motor (`engine/`)
- `CompositionRenderer.kt` → Renderiza la composición en un momento dado usando Canvas (software).
  - En una versión real se reemplazaría por OpenGL ES / Vulkan / Filament para rendimiento.

### UI
- `MainActivity.kt` → Demo simple que muestra un texto animado con motion blur + glow.
- Layout básico con preview, seekbar y botón Play.

## Limitaciones actuales (importante)

- Renderizado por software (Canvas) → lento para resoluciones altas o muchos efectos.
- Motion blur es una **aproximación** (no es un motion blur real de múltiples samples).
- No hay importación de video todavía.
- No hay exportación de video.
- No hay timeline visual completa ni editor de keyframes gráfico.
- No hay sistema de máscaras, blending modes avanzados, ni parenting complejo.

## Cómo continuar el desarrollo

1. **Reemplazar el renderer** por OpenGL ES 3 o Vulkan (o usar una librería como Filament / Sceneform).
2. Añadir `VideoLayer` usando `MediaCodec` + `SurfaceTexture`.
3. Implementar un timeline real con gestos.
4. Añadir más efectos (chromakey, distortion, particle systems…).
5. Sistema de presets / proyectos compartibles.
6. Exportación con `MediaMuxer` + `MediaCodec`.

## Estructura de carpetas

```
MotionEditor/
└── app/src/main/
    ├── java/com/motioneditor/
    │   ├── model/
    │   │   ├── Layer.kt
    │   │   ├── Composition.kt
    │   │   ├── ImageLayer.kt
    │   │   └── TextLayer.kt
    │   ├── effects/
    │   │   └── BasicEffects.kt
    │   ├── engine/
    │   │   └── CompositionRenderer.kt
    │   └── ui/
    │       └── MainActivity.kt
    ├── res/layout/
    │   └── activity_main.xml
    └── AndroidManifest.xml
```

## Nota legal

Este código es original.  
No contiene código, assets ni diseños de Alight Motion ni de ninguna otra aplicación comercial.

---

Creado como base de aprendizaje y prototipo.
Puedes extenderlo libremente.
## Cómo generar el APK

**Opción A – Android Studio**
1. Abre la carpeta `MotionEditor` (File → Open) y espera a que termine el Gradle Sync.
2. Build → Build Bundle(s) / APK(s) → Build APK(s).
3. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

**Opción B – GitHub Actions (sin instalar nada)**
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta (incluida `.github/`).
2. Pestaña *Actions* → workflow **Build APK** → *Run workflow* (también corre solo al hacer push).
3. Al terminar, descarga `MotionEditor-debug-apk` desde *Artifacts* y descomprímelo.

El APK es de depuración (firmado con la clave debug). Para instalarlo en el teléfono hay que permitir la instalación desde orígenes desconocidos.
